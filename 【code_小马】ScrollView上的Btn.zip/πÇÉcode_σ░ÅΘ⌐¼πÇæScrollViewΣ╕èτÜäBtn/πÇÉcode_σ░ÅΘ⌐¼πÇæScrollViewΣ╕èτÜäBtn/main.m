//
//  main.m
//  【code_小马】ScrollView上的Btn
//
//  Created by 马永刚 on 2016/12/27.
//  Copyright © 2016年 马永刚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
