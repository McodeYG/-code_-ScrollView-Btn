//
//  YGButton.h
//  测试一把
//
//  Created by 马永刚 on 2016/12/27.
//  Copyright © 2016年 马永刚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YGButton : UIButton

@end
